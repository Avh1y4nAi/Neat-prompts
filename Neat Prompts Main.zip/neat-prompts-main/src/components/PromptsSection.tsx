import { Download, Upload, SortAsc, SortDesc, Grid3X3, List, LayoutGrid } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PromptCard } from "./PromptCard";
import type { Prompt } from "@/types/prompts";
import { UserMenu } from "./UserMenu";

interface PromptsSectionProps {
  prompts: Prompt[];
  showFavorites: boolean;
  viewMode: "grid" | "list" | "compact";
  sortBy: "newest" | "oldest" | "favorites";
  hasFilters: boolean;
  onViewModeChange: (mode: "grid" | "list" | "compact") => void;
  onSortChange: (sort: "newest" | "oldest" | "favorites") => void;
  onNewPrompt: () => void;
  onEditPrompt: (prompt: Prompt) => void;
  onDeletePrompt: (promptId: string) => void;
  onToggleFavorite: (promptId: string) => void;
  onPromptClick: (prompt: Prompt) => void;
  onExport: () => void;
  onImport: (event: React.ChangeEvent<HTMLInputElement>) => void;
}

export function PromptsSection({
  prompts,
  showFavorites,
  viewMode,
  sortBy,
  hasFilters,
  onViewModeChange,
  onSortChange,
  onNewPrompt,
  onEditPrompt,
  onDeletePrompt,
  onToggleFavorite,
  onPromptClick,
  onExport,
  onImport,
}: PromptsSectionProps) {
  const getGridClassName = () => {
    switch (viewMode) {
      case "list":
        return "grid grid-cols-1 gap-4";
      case "compact":
        return "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3";
      default:
        return "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6";
    }
  };

  return (
    <div className="flex-1 flex flex-col rounded-tl-lg">
              {/* Top Bar */}
        <div className="bg-card p-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <h2 className="text-lg font-semibold">
            {showFavorites ? 'Favorites' : 'All Prompts'} ({prompts.length})
          </h2>
        </div>
        
        <div className="flex items-center gap-2">
          {/* View Mode Toggle */}
          <div className="flex items-center border rounded-lg">
            <Button
              variant={viewMode === "grid" ? "secondary" : "ghost"}
              size="sm"
              onClick={() => onViewModeChange("grid")}
              className="rounded-r-none"
            >
              <LayoutGrid className="w-4 h-4" />
            </Button>
            <Button
              variant={viewMode === "list" ? "secondary" : "ghost"}
              size="sm"
              onClick={() => onViewModeChange("list")}
              className="rounded-none border-x"
            >
              <List className="w-4 h-4" />
            </Button>
            <Button
              variant={viewMode === "compact" ? "secondary" : "ghost"}
              size="sm"
              onClick={() => onViewModeChange("compact")}
              className="rounded-l-none"
            >
              <Grid3X3 className="w-4 h-4" />
            </Button>
          </div>

          {/* Sort */}
          <Button
            variant="outline"
            size="sm"
            onClick={() => onSortChange(sortBy === "newest" ? "oldest" : "newest")}
          >
            {sortBy === "newest" ? <SortDesc className="w-4 h-4" /> : <SortAsc className="w-4 h-4" />}
            {sortBy === "newest" ? "Newest" : "Oldest"}
          </Button>

          {/* Import/Export */}
          <input
            type="file"
            accept=".json"
            onChange={onImport}
            className="hidden"
            id="import-file"
          />
          <Button
            variant="outline"
            size="sm"
            onClick={() => document.getElementById('import-file')?.click()}
          >
            <Upload className="w-4 h-4 mr-2" />
            Import
          </Button>
          <Button variant="outline" size="sm" onClick={onExport}>
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
          <UserMenu />
        </div>
      </div>

      {/* Prompts Grid */}
      <div className="flex-1 p-6 overflow-y-auto">
        {prompts.length > 0 ? (
          <div className={getGridClassName()}>
            {prompts.map((prompt) => (
              <PromptCard
                key={prompt.id}
                prompt={prompt}
                onEdit={onEditPrompt}
                onDelete={onDeletePrompt}
                onToggleFavorite={onToggleFavorite}
                onClick={onPromptClick}
                compact={viewMode === "compact"}
              />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-64 text-center">
            <p className="text-muted-foreground text-lg mb-4">
              {hasFilters
                ? "No prompts match your current filters"
                : showFavorites
                ? "No favorite prompts yet"
                : "No prompts yet"}
            </p>
            <Button onClick={onNewPrompt}>Create Your First Prompt</Button>
          </div>
        )}
      </div>
    </div>
  );
}

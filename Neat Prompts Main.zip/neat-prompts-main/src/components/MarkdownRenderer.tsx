import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import rehypeHighlight from 'rehype-highlight';
import { cn } from '@/lib/utils';

interface MarkdownRendererProps {
  content: string;
  className?: string;
  compact?: boolean;
}

export function MarkdownRenderer({ content, className, compact = false }: MarkdownRendererProps) {
  return (
    <div 
      className={cn(
        "prose prose-sm dark:prose-invert max-w-none",
        compact ? "prose-xs" : "",
        // Custom styling for better integration with the app
        "prose-headings:text-foreground prose-p:text-muted-foreground prose-strong:text-foreground",
        "prose-code:text-foreground prose-code:bg-muted prose-code:px-1 prose-code:py-0.5 prose-code:rounded",
        "prose-pre:bg-muted prose-pre:border prose-pre:border-border",
        "prose-blockquote:border-l-border prose-blockquote:text-muted-foreground",
        "prose-a:text-primary prose-a:no-underline hover:prose-a:underline",
        "prose-ul:text-muted-foreground prose-ol:text-muted-foreground prose-li:text-muted-foreground",
        // Compact mode adjustments
        compact && [
          "prose-headings:text-xs prose-headings:mb-1 prose-headings:mt-2",
          "prose-p:text-xs prose-p:mb-1 prose-p:leading-tight",
          "prose-ul:text-xs prose-ol:text-xs prose-li:text-xs",
          "prose-code:text-xs prose-pre:text-xs",
          "prose-blockquote:text-xs"
        ],
        className
      )}
    >
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        rehypePlugins={[rehypeHighlight]}
        components={{
          // Custom components for better styling
          h1: ({ children }) => (
            <h1 className={cn(
              "font-bold text-foreground",
              compact ? "text-sm mb-1 mt-2" : "text-lg mb-2 mt-3"
            )}>
              {children}
            </h1>
          ),
          h2: ({ children }) => (
            <h2 className={cn(
              "font-semibold text-foreground",
              compact ? "text-xs mb-1 mt-2" : "text-base mb-2 mt-3"
            )}>
              {children}
            </h2>
          ),
          h3: ({ children }) => (
            <h3 className={cn(
              "font-medium text-foreground",
              compact ? "text-xs mb-1 mt-1" : "text-sm mb-1 mt-2"
            )}>
              {children}
            </h3>
          ),
          p: ({ children }) => (
            <p className={cn(
              "text-muted-foreground leading-relaxed",
              compact ? "text-xs mb-1" : "text-sm mb-2"
            )}>
              {children}
            </p>
          ),
          code: ({ inline, children, ...props }) => {
            if (inline) {
              return (
                <code 
                  className={cn(
                    "bg-muted text-foreground px-1 py-0.5 rounded font-mono",
                    compact ? "text-xs" : "text-sm"
                  )}
                  {...props}
                >
                  {children}
                </code>
              );
            }
            return (
              <code 
                className={cn(
                  "block bg-muted text-foreground p-2 rounded border font-mono overflow-x-auto",
                  compact ? "text-xs" : "text-sm"
                )}
                {...props}
              >
                {children}
              </code>
            );
          },
          ul: ({ children }) => (
            <ul className={cn(
              "list-disc list-inside text-muted-foreground space-y-1",
              compact ? "text-xs" : "text-sm"
            )}>
              {children}
            </ul>
          ),
          ol: ({ children }) => (
            <ol className={cn(
              "list-decimal list-inside text-muted-foreground space-y-1",
              compact ? "text-xs" : "text-sm"
            )}>
              {children}
            </ol>
          ),
          li: ({ children }) => (
            <li className={cn(
              "text-muted-foreground",
              compact ? "text-xs" : "text-sm"
            )}>
              {children}
            </li>
          ),
          blockquote: ({ children }) => (
            <blockquote className={cn(
              "border-l-4 border-border pl-4 italic text-muted-foreground",
              compact ? "text-xs my-1" : "text-sm my-2"
            )}>
              {children}
            </blockquote>
          ),
          a: ({ children, href }) => (
            <a 
              href={href}
              className={cn(
                "text-primary hover:underline",
                compact ? "text-xs" : "text-sm"
              )}
              target="_blank"
              rel="noopener noreferrer"
            >
              {children}
            </a>
          ),
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
}

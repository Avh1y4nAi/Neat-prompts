import { useState, useEffect, useMemo } from "react";
import { Search, Command as CommandIcon, Heart } from "lucide-react";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Badge } from "@/components/ui/badge";
import type { Prompt } from "@/types/prompts";

interface CommandPaletteProps {
  prompts: Prompt[];
  onSelectPrompt: (prompt: Prompt) => void;
}

export function CommandPalette({ prompts, onSelectPrompt }: CommandPaletteProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'k' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setIsOpen(true);
      }
      if (e.key === 'Escape') {
        setIsOpen(false);
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);

  const filteredPrompts = useMemo(() => {
    if (!searchQuery) return prompts.slice(0, 10);
    
    const query = searchQuery.toLowerCase();
    return prompts
      .filter(prompt => {
        const titleMatch = prompt.title.toLowerCase().includes(query);
        const categoryName = typeof (prompt as any).category === 'string'
          ? (prompt as any).category
          : (prompt as any).category?.name;
        const categoryMatch = categoryName?.toLowerCase().includes(query) || false;
        const tagsMatch = (prompt.tags || []).some((tag: any) => {
          const tagName = typeof tag === 'string' ? tag : tag?.name;
          return tagName?.toLowerCase().includes(query);
        });
        
        // Handle content search for both string and array types
        let contentMatch = false;
        if (Array.isArray(prompt.content)) {
          contentMatch = prompt.content.some(contentItem => 
            contentItem.toLowerCase().includes(query)
          );
        } else {
          contentMatch = prompt.content.toLowerCase().includes(query);
        }
        
        return titleMatch || contentMatch || categoryMatch || tagsMatch;
      })
      .slice(0, 10);
  }, [prompts, searchQuery]);

  const handleSelect = (prompt: Prompt) => {
    onSelectPrompt(prompt);
    setIsOpen(false);
    setSearchQuery("");
  };

  const handleClose = () => {
    setIsOpen(false);
    setSearchQuery("");
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[700px] p-0 max-h-[80vh] bg-card/95 backdrop-blur-sm border-0 shadow-2xl">
        <DialogTitle className="sr-only">Search Prompts</DialogTitle>
        <Command className="rounded-xl border-0">
          <div className="flex items-center border-b border-border px-4 py-3 bg-gradient-to-r from-primary/10 to-secondary/10">
            <Search className="mr-3 h-5 w-5 shrink-0 text-primary" />
            <CommandInput 
              placeholder="Search prompts by title, content, category, or tags..." 
              value={searchQuery}
              onValueChange={setSearchQuery}
              className="border-0 focus:ring-0 text-lg placeholder:text-muted-foreground/70"
            />
            <div className="flex items-center gap-2 ml-4">
              <kbd className="pointer-events-none inline-flex h-6 select-none items-center gap-1 rounded-md border bg-muted px-2 font-mono text-xs font-medium text-muted-foreground">
                <CommandIcon className="h-3 w-3" />
                K
              </kbd>
              <kbd className="pointer-events-none inline-flex h-6 select-none items-center gap-1 rounded-md border bg-muted px-2 font-mono text-xs font-medium text-muted-foreground">
                ESC
              </kbd>
            </div>
          </div>
          <CommandList className="max-h-[60vh]">
            <CommandEmpty className="py-8 text-center">
              <Search className="mx-auto h-8 w-8 text-muted-foreground mb-2" />
              <p className="text-muted-foreground">No prompts found.</p>
              <p className="text-sm text-muted-foreground/70 mt-1">Try adjusting your search terms.</p>
            </CommandEmpty>
            <CommandGroup heading="Prompts" className="px-2">
              {filteredPrompts.map((prompt) => (
                <CommandItem
                  key={prompt.id}
                  onSelect={() => handleSelect(prompt)}
                  className="flex flex-col items-start gap-2 px-4 py-4 rounded-lg hover:bg-secondary/50 transition-colors cursor-pointer"
                >
                  <div className="flex items-center justify-between w-full">
                    <span className="font-semibold text-foreground">{prompt.title}</span>
                    {(() => {
                      const name = typeof (prompt as any).category === 'string'
                        ? (prompt as any).category
                        : (prompt as any).category?.name;
                      return name;
                    })() && (
                      <Badge variant="secondary" className="text-xs">
                        {typeof (prompt as any).category === 'string' ? (prompt as any).category : (prompt as any).category?.name}
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground line-clamp-2 w-full leading-relaxed">
                    {Array.isArray(prompt.content) 
                      ? prompt.content[0] 
                      : prompt.content
                    }
                    {Array.isArray(prompt.content) && prompt.content.length > 1 && (
                      <span className="text-muted-foreground/70"> +{prompt.content.length - 1} more</span>
                    )}
                  </p>
                  <div className="flex gap-2 flex-wrap">
                    {(prompt.tags || []).slice(0, 4).map((tag: any, index: number) => {
                      const tagId = typeof tag === 'string' ? tag : tag?.id;
                      const tagName = typeof tag === 'string' ? tag : tag?.name;
                      return (
                        <span key={tagId || `${tagName}-${index}`} className="text-xs bg-secondary px-2 py-1 rounded-md text-muted-foreground">
                          {tagName}
                        </span>
                      );
                    })}
                    {prompt.tags.length > 4 && (
                      <span className="text-xs bg-secondary px-2 py-1 rounded-md text-muted-foreground">
                        +{prompt.tags.length - 4}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground/70">
                    <span>Updated {new Intl.DateTimeFormat('en-US', {
                      month: 'short',
                      day: 'numeric',
                      year: 'numeric',
                    }).format(prompt.updatedAt)}</span>
                    {((prompt as any).isFavorite ?? (prompt as any).favorite) && (
                      <Heart className="w-3 h-3 fill-primary text-primary" />
                    )}
                  </div>
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </DialogContent>
    </Dialog>
  );
}
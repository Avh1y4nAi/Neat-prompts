import { Search, Plus, Heart, Folder, Tag, ChevronLeft, ChevronRight, Command, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface NavigationProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onNewPrompt: () => void;
  showFavorites: boolean;
  onToggleFavorites: () => void;
  categories: Array<{ id: string; name: string; count: number }>;
  tags: Array<{ id: string; name: string; count: number }>;
  selectedCategory: string | null;
  selectedTags: string[];
  onCategorySelect: (categoryId: string | null) => void;
  onTagToggle: (tagId: string) => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  onDeleteCategory?: (categoryId: string) => void;
}

export function Navigation({
  searchQuery,
  onSearchChange,
  onNewPrompt,
  showFavorites,
  onToggleFavorites,
  categories,
  tags,
  selectedCategory,
  selectedTags,
  onCategorySelect,
  onTagToggle,
  isCollapsed,
  onToggleCollapse,
  onDeleteCategory,
}: NavigationProps) {
  if (isCollapsed) {
    return (
      <div className="w-16 bg-card h-screen flex flex-col">
        {/* Collapse Toggle */}
        <div className="p-3 border-b border-border flex justify-center">
          <Button
            variant="ghost"
            size="sm"
            onClick={onToggleCollapse}
            className="p-2"
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>

        {/* Collapsed Navigation */}
        <div className="flex-1 overflow-y-auto p-2 space-y-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={onNewPrompt}
            className="w-full p-2"
            title="New Prompt"
          >
            <Plus className="w-4 h-4" />
          </Button>
          
          <Button
            variant={showFavorites ? "secondary" : "ghost"}
            size="sm"
            onClick={onToggleFavorites}
            className="w-full p-2"
            title="Favorites"
          >
            <Heart className="w-4 h-4" />
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="w-64 bg-card h-screen flex flex-col">
      {/* Header */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-xl font-semibold">Prompt Manager</h1>
          <Button
            variant="ghost"
            size="sm"
            onClick={onToggleCollapse}
            className="p-1"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
        </div>
        
        {/* Search */}
        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
          <Input
            placeholder="Search prompts..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="pl-10 pr-16 search-input"
          />
          {/* Command+K indicator */}
          <div className="absolute right-2 top-1/2 transform -translate-y-1/2 flex items-center gap-1">
            <Command className="w-3 h-3 text-muted-foreground/60" />
            <span className="text-xs text-muted-foreground/60 font-mono">K</span>
          </div>
        </div>
        
        {/* New Prompt Button */}
        <Button onClick={onNewPrompt} className="w-full">
          <Plus className="w-4 h-4 mr-2" />
          New Prompt
        </Button>
      </div>

      {/* Navigation */}
      <div className="flex-1 overflow-y-auto p-4">
        {/* Favorites Toggle */}
        <div
          className={`sidebar-item ${showFavorites ? 'active' : ''}`}
          onClick={() => onToggleFavorites()}
        >
          <Heart className="w-4 h-4 mr-3" />
          <span>Favorites</span>
        </div>

        {/* Categories */}
        <div className="mt-6">
          <h3 className="text-sm font-medium text-muted-foreground mb-3 px-3">Categories</h3>
          <div
            className={`sidebar-item ${selectedCategory === null ? 'active' : ''}`}
            onClick={() => onCategorySelect(null)}
          >
            <Folder className="w-4 h-4 mr-3" />
            <span>All Categories</span>
          </div>
          {categories.map((category) => (
            <div
              key={category.id}
              className={`sidebar-item ${selectedCategory === category.id ? 'active' : ''}`}
            >
              <button
                className="flex-1 flex items-center gap-3 text-left"
                onClick={() => onCategorySelect(category.id)}
              >
                <Folder className="w-4 h-4" />
                <span>{category.name}</span>
                <span className="ml-auto text-xs text-muted-foreground">
                  {category.count}
                </span>
              </button>
              {onDeleteCategory && (
                <button
                  className="ml-2 p-1 rounded hover:bg-destructive/10 text-muted-foreground hover:text-destructive"
                  title="Delete category"
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteCategory(category.id);
                  }}
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>
          ))}
        </div>

        {/* Tags */}
        <div className="mt-6">
          <h3 className="text-sm font-medium text-muted-foreground mb-3 px-3">Tags</h3>
          {tags.map((tag) => (
            <div
              key={tag.id}
              className={`sidebar-item ${selectedTags.includes(tag.id) ? 'active' : ''}`}
              onClick={() => onTagToggle(tag.id)}
            >
              <Tag className="w-4 h-4 mr-3" />
              <span>{tag.name}</span>
              <span className="ml-auto text-xs text-muted-foreground">
                {tag.count}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

import { Heart, Edit, Trash2, Copy, Calendar, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { MarkdownRenderer } from "@/components/MarkdownRenderer";
import { useState } from "react";
import type { Prompt } from "@/types/prompts";

interface PromptDetailModalProps {
  prompt: Prompt | null;
  isOpen: boolean;
  onClose: () => void;
  onEdit: (prompt: Prompt) => void;
  onDelete: (promptId: string) => void;
  onToggleFavorite: (promptId: string) => void;
}

export function PromptDetailModal({ 
  prompt, 
  isOpen, 
  onClose, 
  onEdit, 
  onDelete, 
  onToggleFavorite 
}: PromptDetailModalProps) {
  const { toast } = useToast();
  const [copiedStates, setCopiedStates] = useState<{ [key: string]: boolean }>({});
  const [allCopied, setAllCopied] = useState(false);

  if (!prompt) return null;

  const promptId = (prompt as any).id ?? (prompt as any)._id;
  const isFavorite = (prompt as any).favorite ?? (prompt as any).isFavorite ?? false;

  const copyToClipboard = async () => {
    try {
      const contentToCopy = Array.isArray(prompt.content) 
        ? prompt.content.join('\n\n---\n\n') 
        : prompt.content;
      await navigator.clipboard.writeText(contentToCopy);
      setAllCopied(true);
      setTimeout(() => setAllCopied(false), 2000);
    } catch (error) {
      toast({
        title: "Failed to copy",
        description: "Could not copy prompt to clipboard.",
        variant: "destructive",
      });
    }
  };

  const copyIndividualPrompt = async (content: string, promptNumber: number) => {
    try {
      await navigator.clipboard.writeText(content);
      const key = `prompt-${promptNumber}`;
      setCopiedStates(prev => ({ ...prev, [key]: true }));
      setTimeout(() => {
        setCopiedStates(prev => ({ ...prev, [key]: false }));
      }, 2000);
    } catch (error) {
      toast({
        title: "Failed to copy",
        description: `Could not copy prompt ${promptNumber} to clipboard.`,
        variant: "destructive",
      });
    }
  };

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      month: 'long',
      day: 'numeric',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
    }).format(date);
  };

  const handleDelete = () => {
    onDelete(promptId!);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh] flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <div className="flex items-start justify-between">
            <DialogTitle className="text-xl font-semibold pr-8">
              {prompt.title}
            </DialogTitle>
            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onToggleFavorite(promptId!)}
                className="p-2"
                aria-label="favorite"
              >
                <Heart className={`w-4 h-4 ${isFavorite ? 'fill-primary text-primary' : 'text-muted-foreground'}`} />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={copyToClipboard}
                className="p-2"
                aria-label="copy-all"
              >
                {allCopied ? (
                  <Check className="w-4 h-4 text-green-600" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onEdit(prompt)}
                className="p-2"
                aria-label="edit"
              >
                <Edit className="w-4 h-4" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleDelete}
                className="p-2 text-destructive hover:text-destructive"
                aria-label="delete"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </DialogHeader>

        <div className="flex-1 flex flex-col space-y-4 min-h-0">
          {/* Metadata */}
          <div className="flex items-center gap-4 text-sm text-muted-foreground flex-shrink-0">
            <div className="flex items-center gap-1">
              <Calendar className="w-4 h-4" />
              <span>Updated {formatDate(prompt.updatedAt)}</span>
            </div>
            <Badge variant="secondary">{typeof (prompt as any).category === 'string' ? (prompt as any).category : (prompt as any).category?.name}</Badge>
          </div>

          {/* Tags */}
          {prompt.tags.length > 0 && (
            <div className="flex flex-wrap gap-1 flex-shrink-0">
              {(prompt.tags as any).map((tag: any, index: number) => {
                const tagId = typeof tag === 'string' ? tag : tag?.id;
                const tagName = typeof tag === 'string' ? tag : tag?.name;
                return (
                  <Badge key={tagId || `${tagName}-${index}`} variant="outline" className="text-xs">
                    {tagName}
                  </Badge>
                );
              })}
            </div>
          )}

          {/* Content */}
          <div className="flex-1 min-h-0">
            <ScrollArea className="h-[400px] w-full rounded-md border p-4">
            {Array.isArray(prompt.content) ? (
              <div className="space-y-4">
                {prompt.content.map((contentItem, index) => (
                  <div key={index} className="space-y-2">
                    {prompt.content.length > 1 && (
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="text-xs">
                          Prompt {index + 1}
                        </Badge>
                        <div className="flex-1 h-px bg-border"></div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => copyIndividualPrompt(contentItem, index + 1)}
                          className="p-1 h-auto hover:bg-secondary"
                        >
                          {copiedStates[`prompt-${index + 1}`] ? (
                            <Check className="w-3 h-3 text-green-600" />
                          ) : (
                            <Copy className="w-3 h-3 text-muted-foreground" />
                          )}
                        </Button>
                      </div>
                    )}
                    <MarkdownRenderer
                      content={contentItem}
                      className="text-sm leading-relaxed"
                    />
                  </div>
                ))}
              </div>
            ) : (
              <MarkdownRenderer
                content={prompt.content}
                className="text-sm leading-relaxed"
              />
            )}
            </ScrollArea>
          </div>

          {/* Footer */}
          <div className="flex items-center justify-between pt-4 border-t flex-shrink-0">
            <div className="text-xs text-muted-foreground">
              Created {formatDate(prompt.createdAt)}
            </div>
            <Button onClick={copyToClipboard} variant="outline" size="sm">
              {allCopied ? (
                <Check className="w-4 h-4 mr-2 text-green-600" />
              ) : (
                <Copy className="w-4 h-4 mr-2" />
              )}
              {allCopied ? "Copied!" : "Copy All Content"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
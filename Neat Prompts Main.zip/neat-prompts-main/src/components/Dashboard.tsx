import { useState, useMemo } from "react";
import { Navigation } from "./Navigation";
import { PromptsSection } from "./PromptsSection";
import { PromptModal } from "./PromptModal";
import { PromptDetailModal } from "./PromptDetailModal";
import { CommandPalette } from "./CommandPalette";
import type { Prompt as DBPrompt, Category, Tag } from "@/types/prompts";
import { usePrompts } from "@/hooks/usePrompts";

type ViewMode = "grid" | "list" | "compact";

export function Dashboard() {
  const [viewMode, setViewMode] = useState<ViewMode>("grid");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPrompt, setEditingPrompt] = useState<DBPrompt | null>(null);
  const [detailPrompt, setDetailPrompt] = useState<DBPrompt | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const {
    // State
    searchQuery,
    setSearchQuery,
    showFavorites,
    setShowFavorites,
    selectedCategory,
    setSelectedCategory,
    selectedTags,
    setSelectedTags,
    sortBy,
    setSortBy,
    // Data
    prompts,
    categories,
    tags,
    // Actions
    createPrompt,
    updatePrompt,
    deletePrompt,
    toggleFavorite,
    createCategory,
    deleteCategory,
    exportData,
    importData,
    // Computed
    hasFilters,
  } = usePrompts();

  const categoriesWithCounts = useMemo(() => {
    return categories.map((category: Category) => ({
      ...category,
      count: prompts.filter((p) => (p.category as Category | undefined)?.id === category.id).length,
    }));
  }, [categories, prompts]);

  const tagsWithCounts = useMemo(() => {
    return tags
      .map((tag: Tag) => ({
        ...tag,
        count: prompts.filter((p) => (p.tags || []).some((t) => t.id === tag.id)).length,
      }))
      .filter((t) => (t.count || 0) > 0);
  }, [tags, prompts]);

  const handleNewPrompt = () => {
    setEditingPrompt(null);
    setIsModalOpen(true);
  };

  const handleEditPrompt = (prompt: DBPrompt) => {
    setEditingPrompt(prompt);
    setIsModalOpen(true);
  };

  const handleSavePrompt = (promptData: { title: string; content: string | string[]; category: string; tags: string[]; favorite: boolean; }) => {
    const categoryObj = categories.find((c) => c.name === promptData.category);
    const tagObjs = tags.filter((t) => promptData.tags.includes(t.name));

    const payload: Omit<DBPrompt, 'id' | 'createdAt' | 'updatedAt'> = {
      title: promptData.title,
      content: promptData.content,
      description: undefined,
      category: categoryObj,
      tags: tagObjs,
      isFavorite: promptData.favorite,
      usageCount: 0,
      createdAt: new Date(), // will be ignored by service
      updatedAt: new Date(), // will be ignored by service
    } as any;

    if (editingPrompt) {
      updatePrompt(editingPrompt.id, payload as Partial<Omit<DBPrompt, 'id' | 'createdAt'>>);
    } else {
      createPrompt(payload as Omit<DBPrompt, 'id' | 'createdAt' | 'updatedAt'>);
    }
  };

  const handleDeletePrompt = (promptId: string) => {
    deletePrompt(promptId);
  };

  const handleToggleFavorite = (promptId: string) => {
    toggleFavorite(promptId);
  };

  const handlePromptClick = (prompt: DBPrompt) => {
    setDetailPrompt(prompt);
    setIsDetailModalOpen(true);
  };

  const handleCommandPaletteSelect = (prompt: DBPrompt) => {
    handlePromptClick(prompt);
  };

  return (
    <div className="min-h-screen bg-background flex">
      <Navigation
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onNewPrompt={handleNewPrompt}
        showFavorites={showFavorites}
        onToggleFavorites={() => setShowFavorites(!showFavorites)}
        categories={categoriesWithCounts as any}
        tags={tagsWithCounts as any}
        selectedCategory={selectedCategory}
        selectedTags={selectedTags}
        onCategorySelect={setSelectedCategory}
        onTagToggle={(tagId) => {
          if (selectedTags.includes(tagId)) {
            setSelectedTags(selectedTags.filter((id) => id !== tagId));
          } else {
            setSelectedTags([...selectedTags, tagId]);
          }
        }}
        isCollapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        onDeleteCategory={deleteCategory as any}
      />

      <PromptsSection
        prompts={prompts as any}
        showFavorites={showFavorites}
        viewMode={viewMode}
        sortBy={sortBy}
        hasFilters={hasFilters}
        onViewModeChange={setViewMode}
        onSortChange={setSortBy}
        onNewPrompt={handleNewPrompt}
        onEditPrompt={handleEditPrompt as any}
        onDeletePrompt={handleDeletePrompt}
        onToggleFavorite={handleToggleFavorite}
        onPromptClick={handlePromptClick as any}
        onExport={exportData}
        onImport={importData}
      />

      <CommandPalette prompts={prompts as any} onSelectPrompt={handleCommandPaletteSelect as any} />

      <PromptModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSavePrompt as any}
        prompt={editingPrompt as any}
        categories={categories as any}
        tags={tags as any}
        onCreateCategory={createCategory as any}
      />

      <PromptDetailModal
        prompt={detailPrompt as any}
        isOpen={isDetailModalOpen}
        onClose={() => setIsDetailModalOpen(false)}
        onEdit={(prompt) => {
          setIsDetailModalOpen(false);
          handleEditPrompt(prompt as any);
        }}
        onDelete={(promptId) => {
          setIsDetailModalOpen(false);
          handleDeletePrompt(promptId);
        }}
        onToggleFavorite={handleToggleFavorite}
      />
    </div>
  );
}
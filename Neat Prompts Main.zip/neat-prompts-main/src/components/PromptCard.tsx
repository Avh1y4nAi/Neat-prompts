import { Heart, Edit, Trash2, Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { MarkdownRenderer } from "@/components/MarkdownRenderer";
import type { Prompt } from "@/types/prompts";

interface PromptCardProps {
  prompt: Prompt;
  onEdit: (prompt: Prompt) => void;
  onDelete: (promptId: string) => void;
  onToggleFavorite: (promptId: string) => void;
  onClick?: (prompt: Prompt) => void;
  compact?: boolean;
}

export function PromptCard({ prompt, onEdit, onDelete, onToggleFavorite, onClick, compact = false }: PromptCardProps) {
  const { toast } = useToast();

  const copyToClipboard = async () => {
    try {
      const contentToCopy = Array.isArray(prompt.content) 
        ? prompt.content.join('\n\n---\n\n') 
        : prompt.content;
      await navigator.clipboard.writeText(contentToCopy);
      toast({
        title: "Copied to clipboard",
        description: "Prompt content has been copied to your clipboard.",
      });
    } catch (error) {
      toast({
        title: "Failed to copy",
        description: "Could not copy prompt to clipboard.",
        variant: "destructive",
      });
    }
  };

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    }).format(date);
  };

  const isFavorite = (prompt as any).isFavorite ?? (prompt as any).favorite ?? false;
  const categoryName = typeof (prompt as any).category === 'string'
    ? (prompt as any).category
    : (prompt as any).category?.name;

  return (
    <div 
      className={`prompt-card group relative ${onClick ? 'cursor-pointer' : ''} ${compact ? 'compact' : ''}`}
      data-testid="prompt-card"
      onClick={() => onClick?.(prompt)}
    >
      {/* Header */}
      <div className="flex items-start justify-start mb-2">
        <div
          className={`flex-1 mr-2 min-w-0 ${onClick ? 'cursor-pointer' : ''}`}
        >
          <h3 className={`font-semibold text-foreground ${compact ? 'text-sm' : 'text-lg'} truncate`} title={prompt.title}>
            {prompt.title}
          </h3>
        </div>
      </div>

      {/* Content Preview */}
      <div
        className={`${compact ? 'mb-2' : 'mb-3'} ${onClick ? 'cursor-pointer' : ''}`}
      >
        {Array.isArray(prompt.content) ? (
          <div className="space-y-2">
            {prompt.content.slice(0, compact ? 1 : 2).map((contentItem, index) => (
              <div key={index} className={`${compact ? 'line-clamp-2' : 'line-clamp-2'} overflow-hidden`}>
                <MarkdownRenderer
                  content={contentItem}
                  compact={true}
                  className="[&>*]:mb-0 [&>*:last-child]:mb-0"
                />
              </div>
            ))}
            {prompt.content.length > (compact ? 1 : 2) && (
              <p className="text-xs text-muted-foreground/70 italic">
                +{prompt.content.length - (compact ? 1 : 2)} more prompt{prompt.content.length - (compact ? 1 : 2) > 1 ? 's' : ''}
              </p>
            )}
          </div>
        ) : (
          <div className={`${compact ? 'line-clamp-2' : 'line-clamp-3'} overflow-hidden`}>
            <MarkdownRenderer
              content={prompt.content}
              compact={true}
              className="[&>*]:mb-0 [&>*:last-child]:mb-0"
            />
          </div>
        )}
      </div>

      {/* Tags & Category */}
      <div className={`flex flex-wrap gap-1 ${compact ? 'mb-2' : 'mb-3'}`}>
        {categoryName && (
          <Badge variant="secondary" className={compact ? "text-[10px] px-1 py-0 h-4" : "text-xs"}>
            {categoryName}
          </Badge>
        )}
        {(prompt.tags || []).slice(0, compact ? 2 : 5).map((tag: any, index: number) => {
          const tagId = typeof tag === 'string' ? tag : tag?.id;
          const tagName = typeof tag === 'string' ? tag : tag?.name;
          return (
            <Badge key={tagId || `${tagName}-${index}`} variant="outline" className={compact ? "text-[10px] px-1 py-0 h-4" : "text-xs"}>
              {tagName}
            </Badge>
          );
        })}
        {compact && prompt.tags.length > 2 && (
          <Badge variant="outline" className="text-[10px] px-1 py-0 h-4">
            +{prompt.tags.length - 2}
          </Badge>
        )}
      </div>

      {/* Footer with date (left) and actions (right) */}
      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <span className={compact ? 'text-[10px]' : ''}>
          {compact ? formatDate(prompt.updatedAt).replace(', ', ' ') : `Updated ${formatDate(prompt.updatedAt)}`}
        </span>
        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <Button
            variant="ghost"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              onToggleFavorite(prompt.id);
            }}
            className="p-1 h-auto"
            aria-label="favorite"
          >
            <Heart 
              className={`w-3 h-3 ${isFavorite ? 'fill-primary text-primary' : 'text-muted-foreground'}`} 
            />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              copyToClipboard();
            }}
            className="p-1 h-auto"
            aria-label="copy"
          >
            <Copy className="w-3 h-3 text-muted-foreground" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              onEdit(prompt);
            }}
            className="p-1 h-auto"
            aria-label="edit"
          >
            <Edit className="w-3 h-3 text-muted-foreground" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              onDelete(prompt.id);
            }}
            className="p-1 h-auto"
            aria-label="delete"
          >
            <Trash2 className="w-3 h-3 text-muted-foreground hover:text-destructive" />
          </Button>
        </div>
      </div>
    </div>
  );
}
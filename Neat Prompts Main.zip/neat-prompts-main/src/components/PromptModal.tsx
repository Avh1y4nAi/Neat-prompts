import { useState, useEffect } from "react";
import { X, Plus, Trash2, Eye, Edit3 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MarkdownRenderer } from "@/components/MarkdownRenderer";
import type { Category, Tag, Prompt as DBPrompt } from "@/types/prompts";

export interface PromptModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (prompt: Omit<DBPrompt, 'id' | 'createdAt' | 'updatedAt'>) => void;
  prompt?: DBPrompt | null;
  categories: Category[];
  tags: Tag[];
  onCreateCategory?: (name: string) => void;
}

export function PromptModal({ isOpen, onClose, onSave, prompt, categories, tags, onCreateCategory }: PromptModalProps) {
  const [title, setTitle] = useState("");
  const [contentItems, setContentItems] = useState<string[]>([""]);
  const [category, setCategory] = useState("");
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [favorite, setFavorite] = useState(false);
  const [newTag, setNewTag] = useState("");
  const [newCategory, setNewCategory] = useState("");
  const [activeTab, setActiveTab] = useState("edit");

  useEffect(() => {
    if (prompt) {
      setTitle(prompt.title);
      if (Array.isArray(prompt.content)) {
        setContentItems(prompt.content.length > 0 ? prompt.content : [""]);
      } else {
        setContentItems([prompt.content]);
      }
      setCategory(typeof (prompt as any).category === 'string' ? (prompt as any).category : (prompt as any).category?.name || "");
      setSelectedTags((prompt.tags as any).map((t: any) => (typeof t === 'string' ? t : t?.name)).filter(Boolean));
      setFavorite((prompt as any).favorite ?? (prompt as any).isFavorite ?? false);
    } else {
      setTitle("");
      setContentItems([""]);
      setCategory("");
      setSelectedTags([]);
      setFavorite(false);
    }
    setNewTag("");
    setNewCategory("");
  }, [prompt, isOpen]);

  const handleSave = () => {
    if (!title.trim() || !contentItems.some(item => item.trim()) || !category) {
      return;
    }

    // Filter out empty content items
    const validContentItems = contentItems.filter(item => item.trim());
    
    // If only one content item, save as string; otherwise save as array
    const content = validContentItems.length === 1 ? validContentItems[0] : validContentItems;

    const categoryObj = categories.find((c) => c.name === category);
    const tagObjs = tags.filter((t) => selectedTags.includes(t.name));

    onSave({
      title: title.trim(),
      content,
      description: undefined,
      category: categoryObj,
      tags: tagObjs,
      isFavorite: favorite,
      usageCount: (prompt as any)?.usageCount ?? 0,
      createdAt: new Date(),
      updatedAt: new Date(),
    } as any);

    onClose();
  };

  const addContentItem = () => {
    setContentItems([...contentItems, ""]);
  };

  const removeContentItem = (index: number) => {
    if (contentItems.length > 1) {
      setContentItems(contentItems.filter((_, i) => i !== index));
    }
  };

  const updateContentItem = (index: number, value: string) => {
    const newContentItems = [...contentItems];
    newContentItems[index] = value;
    setContentItems(newContentItems);
  };

  const addTag = () => {
    if (newTag.trim() && !selectedTags.includes(newTag.trim())) {
      setSelectedTags([...selectedTags, newTag.trim()]);
      setNewTag("");
    }
  };

  const removeTag = (tagToRemove: string) => {
    setSelectedTags(selectedTags.filter(tag => tag !== tagToRemove));
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && newTag.trim()) {
      e.preventDefault();
      addTag();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[700px] bg-card max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {prompt ? 'Edit Prompt' : 'New Prompt'}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Title */}
          <div className="space-y-2">
            <Label htmlFor="title">Title</Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Enter prompt title..."
            />
          </div>

          {/* Content Items with Preview */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label>Prompt Content</Label>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={addContentItem}
                className="flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                Add Another
              </Button>
            </div>

            {contentItems.map((content, index) => (
              <div key={index} className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor={`content-${index}`}>
                    {contentItems.length === 1 ? "Content" : `Prompt ${index + 1}`}
                  </Label>
                  {contentItems.length > 1 && (
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeContentItem(index)}
                      className="text-destructive hover:text-destructive hover:bg-destructive/10"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                </div>

                <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="edit" className="flex items-center gap-2">
                      <Edit3 className="w-4 h-4" />
                      Edit
                    </TabsTrigger>
                    <TabsTrigger value="preview" className="flex items-center gap-2">
                      <Eye className="w-4 h-4" />
                      Preview
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="edit" className="mt-2">
                    <Textarea
                      id={`content-${index}`}
                      value={content}
                      onChange={(e) => updateContentItem(index, e.target.value)}
                      placeholder={contentItems.length === 1 ? "Enter your prompt content... (Markdown supported)" : `Enter prompt ${index + 1} content... (Markdown supported)`}
                      rows={6}
                      className="font-mono text-sm"
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      Supports Markdown: **bold**, *italic*, `code`, # headers, lists, links, etc.
                    </p>
                  </TabsContent>

                  <TabsContent value="preview" className="mt-2">
                    <div className="min-h-[150px] p-3 border rounded-md bg-muted/30">
                      {content.trim() ? (
                        <MarkdownRenderer content={content} />
                      ) : (
                        <p className="text-muted-foreground italic text-sm">
                          No content to preview. Switch to Edit tab to add content.
                        </p>
                      )}
                    </div>
                  </TabsContent>
                </Tabs>
              </div>
            ))}
          </div>

          {/* Category */}
          <div className="space-y-2">
            <Label htmlFor="category">Category</Label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger aria-label="Category" data-testid="category-select-trigger">
                <SelectValue placeholder="Select a category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((cat) => (
                  <SelectItem key={cat.id} value={cat.name}>
                    {cat.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {/* Create Category Inline */}
            <div className="flex gap-2 mt-2">
              <Input
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
                placeholder="Create new category..."
                className="flex-1"
              />
              <Button
                type="button"
                variant="outline"
                disabled={!newCategory.trim()}
                onClick={() => {
                  const name = newCategory.trim();
                  if (!name) return;
                  setCategory(name);
                  onCreateCategory?.(name);
                  setNewCategory("");
                }}
              >
                Add
              </Button>
            </div>
          </div>

          {/* Tags */}
          <div className="space-y-2">
            <Label>Tags</Label>
            
            {/* Selected Tags */}
            {selectedTags.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-2">
                {selectedTags.map((tag) => (
                  <Badge key={tag} variant="secondary" className="px-2 py-1">
                    {tag}
                    <button
                      onClick={() => removeTag(tag)}
                      className="ml-2 text-muted-foreground hover:text-foreground"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}

            {/* Add New Tag */}
            <div className="flex gap-2">
              <Input
                value={newTag}
                onChange={(e) => setNewTag(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Add a tag..."
                className="flex-1"
              />
              <Button onClick={addTag} variant="outline" disabled={!newTag.trim()} data-testid="add-tag">
                Add
              </Button>
            </div>

            {/* Available Tags */}
            <div className="flex flex-wrap gap-2 mt-2">
              {tags
                .filter(tag => !selectedTags.includes(tag.name))
                .map((tag) => (
                  <Badge
                    key={tag.id}
                    variant="outline"
                    className="cursor-pointer hover:bg-secondary"
                    onClick={() => setSelectedTags([...selectedTags, tag.name])}
                  >
                    + {tag.name}
                  </Badge>
                ))}
            </div>
          </div>

          {/* Favorite Toggle */}
          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              id="favorite"
              checked={favorite}
              onChange={(e) => setFavorite(e.target.checked)}
              className="rounded border-border"
            />
            <Label htmlFor="favorite">Mark as favorite</Label>
          </div>
        </div>

        {/* Actions */}
        <div className="flex justify-end space-x-2">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button 
            onClick={handleSave}
            disabled={!title.trim() || !contentItems.some(item => item.trim()) || !category}
          >
            {prompt ? 'Update' : 'Create'} Prompt
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
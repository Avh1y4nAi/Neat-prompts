import { useState, useEffect, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabasePromptService } from '@/lib/supabasePromptService';
import type { Prompt, Category, Tag } from '@/types/prompts';
import { useToast } from './use-toast';

export function usePrompts() {
  const [searchQuery, setSearchQuery] = useState("");
  const [showFavorites, setShowFavorites] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [sortBy, setSortBy] = useState<"newest" | "oldest" | "favorites">("newest");
  
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const promptService = supabasePromptService;

  // No need to initialize collections with Supabase
  // useEffect(() => {
  //   promptService.initializeCollections().catch(console.error);
  // }, []);

  // Queries
  const {
    data: prompts = [],
    isLoading: promptsLoading,
    error: promptsError,
  } = useQuery({
    queryKey: ['prompts'],
    queryFn: () => promptService.getAllPrompts(),
  });

  const {
    data: categories = [],
    isLoading: categoriesLoading,
  } = useQuery({
    queryKey: ['categories'],
    queryFn: () => promptService.getAllCategories(),
  });

  const {
    data: tags = [],
    isLoading: tagsLoading,
  } = useQuery({
    queryKey: ['tags'],
    queryFn: () => promptService.getAllTags(),
  });

  // Search prompts query
  const {
    data: searchResults = [],
    isLoading: searchLoading,
  } = useQuery({
    queryKey: ['search', searchQuery, showFavorites, selectedCategory, selectedTags],
    queryFn: () => promptService.searchPrompts(searchQuery),
    enabled: !!searchQuery || showFavorites || !!selectedCategory || selectedTags.length > 0,
  });

  // Mutations
  const createPromptMutation = useMutation({
    mutationFn: (promptData: Omit<Prompt, 'id' | 'createdAt' | 'updatedAt'>) =>
      promptService.createPrompt(promptData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['prompts'] });
      queryClient.invalidateQueries({ queryKey: ['categories'] });
      queryClient.invalidateQueries({ queryKey: ['tags'] });
      toast({
        title: "Prompt created",
        description: "Your new prompt has been successfully created.",
      });
    },
    onError: (error) => {
      console.error('Error creating prompt:', error);
      toast({
        title: "Error",
        description: "Failed to create prompt. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updatePromptMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<Omit<Prompt, 'id' | 'createdAt'>> }) =>
      promptService.updatePrompt(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['prompts'] });
      queryClient.invalidateQueries({ queryKey: ['categories'] });
      queryClient.invalidateQueries({ queryKey: ['tags'] });
      toast({
        title: "Prompt updated",
        description: "Your prompt has been successfully updated.",
      });
    },
    onError: (error) => {
      console.error('Error updating prompt:', error);
      toast({
        title: "Error",
        description: "Failed to update prompt. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deletePromptMutation = useMutation({
    mutationFn: (id: string) => promptService.deletePrompt(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['prompts'] });
      queryClient.invalidateQueries({ queryKey: ['categories'] });
      queryClient.invalidateQueries({ queryKey: ['tags'] });
      toast({
        title: "Prompt deleted",
        description: "The prompt has been successfully deleted.",
      });
    },
    onError: (error) => {
      console.error('Error deleting prompt:', error);
      toast({
        title: "Error",
        description: "Failed to delete prompt. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Category mutations
  const createCategoryMutation = useMutation({
    mutationFn: (category: Omit<Category, 'id'>) => promptService.createCategory(category),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['categories'] });
      toast({
        title: 'Category created',
        description: 'Your new category has been successfully created.',
      });
    },
    onError: (error) => {
      console.error('Error creating category:', error);
      toast({
        title: 'Error',
        description: 'Failed to create category. Please try again.',
        variant: 'destructive',
      });
    },
  });

  const deleteCategoryMutation = useMutation({
    mutationFn: (categoryId: string) => promptService.deleteCategory(categoryId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['categories'] });
      queryClient.invalidateQueries({ queryKey: ['prompts'] });
      toast({
        title: 'Category deleted',
        description: 'The category has been removed.',
      });
    },
    onError: (error) => {
      console.error('Error deleting category:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete category. Please try again.',
        variant: 'destructive',
      });
    },
  });

  const toggleFavoriteMutation = useMutation({
    mutationFn: async (id: string) => {
      const prompt = await promptService.getPromptById(id);
      if (!prompt) throw new Error('Prompt not found');
      return promptService.updatePrompt(id, { isFavorite: !prompt.isFavorite });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['prompts'] });
      queryClient.invalidateQueries({ queryKey: ['search'] });
    },
    onError: (error) => {
      console.error('Error toggling favorite:', error);
      toast({
        title: "Error",
        description: "Failed to update favorite status. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Computed values
  const filteredPrompts = useCallback(() => {
    if (searchQuery || showFavorites || selectedCategory || selectedTags.length > 0) {
      return searchResults;
    }
    return prompts;
  }, [searchQuery, showFavorites, selectedCategory, selectedTags, searchResults, prompts]);

  const sortedPrompts = useCallback(() => {
    const promptsToSort = filteredPrompts();
    
    switch (sortBy) {
      case "newest":
        return [...promptsToSort].sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime());
      case "oldest":
        return [...promptsToSort].sort((a, b) => a.updatedAt.getTime() - b.updatedAt.getTime());
      case "favorites":
        return [...promptsToSort].sort((a, b) => {
          if (a.isFavorite === b.isFavorite) {
            return b.updatedAt.getTime() - a.updatedAt.getTime();
          }
          return a.isFavorite ? -1 : 1;
        });
      default:
        return promptsToSort;
    }
  }, [filteredPrompts, sortBy]);

  // Actions
  const handleCreatePrompt = useCallback((promptData: Omit<Prompt, 'id' | 'createdAt' | 'updatedAt'>) => {
    createPromptMutation.mutate(promptData);
  }, [createPromptMutation]);

  const handleUpdatePrompt = useCallback((id: string, promptData: Partial<Omit<Prompt, 'id' | 'createdAt'>>) => {
    updatePromptMutation.mutate({ id, data: promptData });
  }, [updatePromptMutation]);

  const handleDeletePrompt = useCallback((id: string) => {
    deletePromptMutation.mutate(id);
  }, [deletePromptMutation]);

  const handleToggleFavorite = useCallback((id: string) => {
    toggleFavoriteMutation.mutate(id);
  }, [toggleFavoriteMutation]);

  const handleCreateCategory = useCallback((name: string) => {
    if (!name.trim()) return;
    createCategoryMutation.mutate({ name: name.trim() } as Omit<Category, 'id'>);
  }, [createCategoryMutation]);

  const handleDeleteCategory = useCallback((categoryId: string) => {
    if (!categoryId) return;
    // If the deleted category is selected, clear selection
    if (selectedCategory === categoryId) setSelectedCategory(null);
    deleteCategoryMutation.mutate(categoryId);
  }, [deleteCategoryMutation, selectedCategory, setSelectedCategory]);

  // Export/Import functionality not yet implemented for Supabase
  // TODO: Implement export/import when needed
  const handleExport = useCallback(async () => {
    toast({
      title: "Export not available",
      description: "Export functionality is not yet implemented for Supabase.",
      variant: "destructive",
    });
  }, [toast]);

  const handleImport = useCallback(async (event: React.ChangeEvent<HTMLInputElement>) => {
    toast({
      title: "Import not available",
      description: "Import functionality is not yet implemented for Supabase.",
      variant: "destructive",
    });
    // Reset the input
    event.target.value = '';
  }, [toast]);

  return {
    // State
    searchQuery,
    setSearchQuery,
    showFavorites,
    setShowFavorites,
    selectedCategory,
    setSelectedCategory,
    selectedTags,
    setSelectedTags,
    sortBy,
    setSortBy,
    
    // Data
    prompts: sortedPrompts(),
    categories,
    tags,
    
    // Loading states
    isLoading: promptsLoading || categoriesLoading || tagsLoading,
    searchLoading,
    isCreating: createPromptMutation.isPending,
    isUpdating: updatePromptMutation.isPending,
    isDeleting: deletePromptMutation.isPending,
    isTogglingFavorite: toggleFavoriteMutation.isPending,
    isCreatingCategory: createCategoryMutation.isPending,
    isDeletingCategory: deleteCategoryMutation.isPending,
    
    // Errors
    promptsError,
    
    // Actions
    createPrompt: handleCreatePrompt,
    updatePrompt: handleUpdatePrompt,
    deletePrompt: handleDeletePrompt,
    toggleFavorite: handleToggleFavorite,
    createCategory: handleCreateCategory,
    deleteCategory: handleDeleteCategory,
    exportData: handleExport,
    importData: handleImport,
    
    // Computed
    hasFilters: !!(searchQuery || showFavorites || selectedCategory || selectedTags.length > 0),
  };
}

export type ThemeVariables = {
  background: string
  foreground: string
  card: string
  'card-foreground': string
  popover: string
  'popover-foreground': string
  primary: string
  'primary-foreground': string
  secondary: string
  'secondary-foreground': string
  muted: string
  'muted-foreground': string
  accent: string
  'accent-foreground': string
  destructive: string
  'destructive-foreground': string
  border: string
  input: string
  ring: string
  // Sidebar palette
  'sidebar-background': string
  'sidebar-foreground': string
  'sidebar-primary': string
  'sidebar-primary-foreground': string
  'sidebar-accent': string
  'sidebar-accent-foreground': string
  'sidebar-border': string
  'sidebar-ring': string
}

export const defaultTheme: ThemeVariables = {
  background: '15 12% 11%',
  foreground: '0 0% 95%',
  card: '15 7% 16%',
  'card-foreground': '0 0% 95%',
  popover: '15 7% 16%',
  'popover-foreground': '0 0% 95%',
  primary: '15 68% 36%',
  'primary-foreground': '0 0% 98%',
  secondary: '15 13% 21%',
  'secondary-foreground': '0 0% 85%',
  muted: '15 13% 21%',
  'muted-foreground': '0 0% 65%',
  accent: '15 68% 36%',
  'accent-foreground': '0 0% 98%',
  destructive: '0 68% 50%',
  'destructive-foreground': '0 0% 98%',
  border: '15 16% 27%',
  input: '15 7% 16%',
  ring: '15 68% 36%',
  'sidebar-background': '0 0% 98%',
  'sidebar-foreground': '240 5.3% 26.1%',
  'sidebar-primary': '240 5.9% 10%',
  'sidebar-primary-foreground': '0 0% 98%',
  'sidebar-accent': '240 4.8% 95.9%',
  'sidebar-accent-foreground': '240 5.9% 10%',
  'sidebar-border': '220 13% 91%',
  'sidebar-ring': '217.2 91.2% 59.8%',
}

// A premade alternative theme (cool blue)
export const premadeTheme: ThemeVariables = {
  background: '222 47% 11%',
  foreground: '210 40% 98%',
  card: '222 41% 16%',
  'card-foreground': '210 40% 98%',
  popover: '222 41% 16%',
  'popover-foreground': '210 40% 98%',
  primary: '221 83% 53%',
  'primary-foreground': '0 0% 100%',
  secondary: '224 47% 20%',
  'secondary-foreground': '210 40% 96%',
  muted: '224 47% 20%',
  'muted-foreground': '215 20% 65%',
  accent: '199 89% 48%',
  'accent-foreground': '210 40% 98%',
  destructive: '0 72% 51%',
  'destructive-foreground': '0 0% 98%',
  border: '223 44% 25%',
  input: '222 41% 16%',
  ring: '221 83% 53%',
  'sidebar-background': '222 41% 16%',
  'sidebar-foreground': '210 40% 96%',
  'sidebar-primary': '221 83% 53%',
  'sidebar-primary-foreground': '0 0% 100%',
  'sidebar-accent': '224 47% 20%',
  'sidebar-accent-foreground': '210 40% 96%',
  'sidebar-border': '223 44% 25%',
  'sidebar-ring': '199 89% 48%',
}

export function applyTheme(vars: Partial<ThemeVariables>) {
  const root = document.documentElement
  Object.entries(vars).forEach(([key, value]) => {
    if (value) root.style.setProperty(`--${key}`, value)
  })
}

// ---------- Color conversion helpers (Hex <-> HSL string "H S% L%") ----------

function clamp01(n: number) { return Math.min(1, Math.max(0, n)) }

export function hslToHex(h: number, sPct: number, lPct: number): string {
  const s = clamp01(sPct / 100)
  const l = clamp01(lPct / 100)
  const c = (1 - Math.abs(2 * l - 1)) * s
  const hp = ((h % 360) + 360) % 360 / 60
  const x = c * (1 - Math.abs((hp % 2) - 1))
  let r = 0, g = 0, b = 0
  if (hp >= 0 && hp < 1) { r = c; g = x; b = 0 }
  else if (hp >= 1 && hp < 2) { r = x; g = c; b = 0 }
  else if (hp >= 2 && hp < 3) { r = 0; g = c; b = x }
  else if (hp >= 3 && hp < 4) { r = 0; g = x; b = c }
  else if (hp >= 4 && hp < 5) { r = x; g = 0; b = c }
  else { r = c; g = 0; b = x }
  const m = l - c / 2
  const R = Math.round((r + m) * 255)
  const G = Math.round((g + m) * 255)
  const B = Math.round((b + m) * 255)
  const toHex = (n: number) => n.toString(16).padStart(2, '0')
  return `#${toHex(R)}${toHex(G)}${toHex(B)}`
}

export function hexToHsl(hex: string): { h: number; s: number; l: number } {
  const clean = hex.replace('#', '')
  const bigint = parseInt(clean.length === 3
    ? clean.split('').map(c => c + c).join('')
    : clean, 16)
  const r = (bigint >> 16) & 255
  const g = (bigint >> 8) & 255
  const b = bigint & 255
  const rn = r / 255, gn = g / 255, bn = b / 255
  const max = Math.max(rn, gn, bn), min = Math.min(rn, gn, bn)
  let h = 0, s = 0
  const l = (max + min) / 2
  const d = max - min
  if (d !== 0) {
    s = d / (1 - Math.abs(2 * l - 1))
    switch (max) {
      case rn: h = 60 * (((gn - bn) / d) % 6); break
      case gn: h = 60 * (((bn - rn) / d) + 2); break
      case bn: h = 60 * (((rn - gn) / d) + 4); break
    }
  }
  if (h < 0) h += 360
  return { h: Math.round(h), s: Math.round(s * 100), l: Math.round(l * 100) }
}

export function hslStringToHex(hsl: string): string {
  const { h, s, l } = parseHslString(hsl)
  return hslToHex(h, s, l)
}

export function hexToHslString(hex: string): string {
  const { h, s, l } = hexToHsl(hex)
  return `${h} ${s}% ${l}%`
}

export function parseHslString(hsl: string): { h: number; s: number; l: number } {
  // Accept formats like "h s% l%" or "h, s%, l%" or with extra spaces
  const parts = hsl.replace(/,/g, ' ').trim().split(/\s+/)
  const h = parseFloat(parts[0] || '0')
  const s = parseFloat((parts[1] || '0').toString().replace('%', ''))
  const l = parseFloat((parts[2] || '0').toString().replace('%', ''))
  return { h, s, l }
}



import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables. Please check your .env file.')
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Database table names
export const TABLES = {
  PROMPTS: 'prompts',
  CATEGORIES: 'categories',
  TAGS: 'tags',
  PROMPT_TAGS: 'prompt_tags',
} as const

// Database types (you can generate these from Supabase CLI)
export interface Database {
  public: {
    Tables: {
      prompts: {
        Row: {
          id: string
          title: string
          content: string
          description: string | null
          category_id: string | null
          created_at: string
          updated_at: string
          user_id: string | null
          is_favorite: boolean
          usage_count: number
        }
        Insert: {
          id?: string
          title: string
          content: string
          description?: string | null
          category_id?: string | null
          created_at?: string
          updated_at?: string
          user_id?: string | null
          is_favorite?: boolean
          usage_count?: number
        }
        Update: {
          id?: string
          title?: string
          content?: string
          description?: string | null
          category_id?: string | null
          created_at?: string
          updated_at?: string
          user_id?: string | null
          is_favorite?: boolean
          usage_count?: number
        }
      }
      categories: {
        Row: {
          id: string
          name: string
          description: string | null
          color: string | null
          created_at: string
          user_id: string | null
        }
        Insert: {
          id?: string
          name: string
          description?: string | null
          color?: string | null
          created_at?: string
          user_id?: string | null
        }
        Update: {
          id?: string
          name?: string
          description?: string | null
          color?: string | null
          created_at?: string
          user_id?: string | null
        }
      }
      tags: {
        Row: {
          id: string
          name: string
          color: string | null
          created_at: string
          user_id: string | null
        }
        Insert: {
          id?: string
          name: string
          color?: string | null
          created_at?: string
          user_id?: string | null
        }
        Update: {
          id?: string
          name?: string
          color?: string | null
          created_at?: string
          user_id?: string | null
        }
      }
      prompt_tags: {
        Row: {
          id: string
          prompt_id: string
          tag_id: string
          created_at: string
        }
        Insert: {
          id?: string
          prompt_id: string
          tag_id: string
          created_at?: string
        }
        Update: {
          id?: string
          prompt_id?: string
          tag_id?: string
          created_at?: string
        }
      }
    }
  }
}

import { supabase, TABLES, Database } from './supabase'
import type { Prompt, Category, Tag } from '../types/prompts'

type PromptRow = Database['public']['Tables']['prompts']['Row']
type CategoryRow = Database['public']['Tables']['categories']['Row']
type TagRow = Database['public']['Tables']['tags']['Row']

export class SupabasePromptService {
  // Test connection method
  async testConnection(): Promise<boolean> {
    try {
      const { data, error } = await supabase
        .from(TABLES.PROMPTS)
        .select('id')
        .limit(1)
      
      if (error) {
        console.error('Connection test failed:', error)
        return false
      }
      
      return true
    } catch (error) {
      console.error('Connection test error:', error)
      return false
    }
  }

  // Prompts
  async getAllPrompts(): Promise<Prompt[]> {
    try {
      // First, let's try a simple query without joins
      const userId = (await supabase.auth.getUser()).data.user?.id
      const { data, error } = await supabase
        .from(TABLES.PROMPTS)
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })

      if (error) {
        console.error('Error fetching prompts:', error)
        throw new Error(`Failed to fetch prompts: ${error.message}`)
      }

      // Use mapPromptFromRow to ensure consistent content processing
      return (data || []).map(row => this.mapPromptFromRow(row));
    } catch (error) {
      console.error('Error in getAllPrompts:', error)
      throw error
    }
  }

  async getPromptById(id: string): Promise<Prompt | null> {
    const userId = (await supabase.auth.getUser()).data.user?.id
    const { data, error } = await supabase
      .from(TABLES.PROMPTS)
      .select(`
        *,
        categories(name, color),
        prompt_tags(
          tags(name, color)
        )
      `)
      .eq('id', id)
      .eq('user_id', userId)
      .single()

    if (error) {
      console.error('Error fetching prompt:', error)
      return null
    }

    return this.mapPromptFromRow(data)
  }

  async createPrompt(prompt: Omit<Prompt, 'id' | 'createdAt' | 'updatedAt'>): Promise<Prompt> {
    // Convert content to string if it's an array
    const content = Array.isArray(prompt.content) ? prompt.content.join('\n\n') : prompt.content
    
    const userId = (await supabase.auth.getUser()).data.user?.id || null
    const promptData = {
      title: prompt.title,
      content,
      description: prompt.description,
      category_id: prompt.category?.id || null,
      is_favorite: prompt.isFavorite,
      usage_count: prompt.usageCount,
      user_id: userId,
    }

    const { data, error } = await supabase
      .from(TABLES.PROMPTS)
      .insert(promptData)
      .select()
      .single()

    if (error) {
      console.error('Error creating prompt:', error)
      throw new Error('Failed to create prompt')
    }

    // Create prompt-tag relationships if tags exist
    if (prompt.tags && prompt.tags.length > 0) {
      await this.createPromptTags(data.id, prompt.tags)
    }

    return this.mapPromptFromRow(data)
  }

  async updatePrompt(id: string, updates: Partial<Prompt>): Promise<Prompt> {
    const userId = (await supabase.auth.getUser()).data.user?.id
    const updateData: any = {}
    
    if (updates.title !== undefined) updateData.title = updates.title
    if (updates.content !== undefined) {
      // Convert content to string if it's an array
      updateData.content = Array.isArray(updates.content) ? updates.content.join('\n\n') : updates.content
    }
    if (updates.description !== undefined) updateData.description = updates.description
    if (updates.category !== undefined) updateData.category_id = updates.category?.id || null
    if (updates.isFavorite !== undefined) updateData.is_favorite = updates.isFavorite
    if (updates.usageCount !== undefined) updateData.usage_count = updates.usageCount
    updateData.updated_at = new Date().toISOString()

    const { data, error } = await supabase
      .from(TABLES.PROMPTS)
      .update(updateData)
      .eq('id', id)
      .eq('user_id', userId)
      .select()
      .single()

    if (error) {
      console.error('Error updating prompt:', error)
      throw new Error('Failed to update prompt')
    }

    // Update tags if provided
    if (updates.tags !== undefined) {
      await this.updatePromptTags(id, updates.tags)
    }

    return this.mapPromptFromRow(data)
  }

  async deletePrompt(id: string): Promise<void> {
    // Delete prompt-tag relationships first
    const { error: ptError } = await supabase
      .from(TABLES.PROMPT_TAGS)
      .delete()
      .eq('prompt_id', id)

    if (ptError) {
      console.error('Error deleting prompt tags:', ptError)
    }

    // Delete the prompt and ensure a row was actually deleted
    const { data, error } = await supabase
      .from(TABLES.PROMPTS)
      .delete()
      .eq('id', id)
      .select('id')
      .single()

    if (error) {
      console.error('Error deleting prompt:', error)
      throw new Error('Failed to delete prompt')
    }
    if (!data) {
      throw new Error('Prompt not found or not deleted')
    }
  }

  async searchPrompts(query: string): Promise<Prompt[]> {
    const userId = (await supabase.auth.getUser()).data.user?.id
    const { data, error } = await supabase
      .from(TABLES.PROMPTS)
      .select(`
        *,
        categories(name, color),
        prompt_tags(
          tags(name, color)
        )
      `)
      .eq('user_id', userId)
      .or(`title.ilike.%${query}%,content.ilike.%${query}%,description.ilike.%${query}%`)
      .order('created_at', { ascending: false })

    if (error) {
      console.error('Error searching prompts:', error)
      throw new Error('Failed to search prompts')
    }

    return this.mapPromptsFromRows(data || [])
  }

  // Categories
  async getAllCategories(): Promise<Category[]> {
    const userId = (await supabase.auth.getUser()).data.user?.id
    const { data, error } = await supabase
      .from(TABLES.CATEGORIES)
      .select('*')
      .eq('user_id', userId)
      .order('name')

    if (error) {
      console.error('Error fetching categories:', error)
      throw new Error('Failed to fetch categories')
    }

    return (data || []).map(this.mapCategoryFromRow)
  }

  async createCategory(category: Omit<Category, 'id'>): Promise<Category> {
    const userId = (await supabase.auth.getUser()).data.user?.id || null
    const { data, error } = await supabase
      .from(TABLES.CATEGORIES)
      .insert({
        name: category.name,
        description: category.description,
        color: category.color,
        user_id: userId,
      })
      .select()
      .single()

    if (error) {
      console.error('Error creating category:', error)
      throw new Error('Failed to create category')
    }

    return this.mapCategoryFromRow(data)
  }

  async deleteCategory(categoryId: string): Promise<void> {
    // Before deleting, set category_id to null for any prompts using this category
    const userId = (await supabase.auth.getUser()).data.user?.id
    const { error: updateError } = await supabase
      .from(TABLES.PROMPTS)
      .update({ category_id: null })
      .eq('category_id', categoryId)
      .eq('user_id', userId)

    if (updateError) {
      console.error('Error clearing category from prompts:', updateError)
      throw new Error('Failed to clear category from prompts')
    }

    const { error } = await supabase
      .from(TABLES.CATEGORIES)
      .delete()
      .eq('id', categoryId)

    if (error) {
      console.error('Error deleting category:', error)
      throw new Error('Failed to delete category')
    }
  }

  // Tags
  async getAllTags(): Promise<Tag[]> {
    const userId = (await supabase.auth.getUser()).data.user?.id
    const { data, error } = await supabase
      .from(TABLES.TAGS)
      .select('*')
      .eq('user_id', userId)
      .order('name')

    if (error) {
      console.error('Error fetching tags:', error)
      throw new Error('Failed to fetch tags')
    }

    return (data || []).map(this.mapTagFromRow)
  }

  async createTag(tag: Omit<Tag, 'id'>): Promise<Tag> {
    const userId = (await supabase.auth.getUser()).data.user?.id || null
    const { data, error } = await supabase
      .from(TABLES.TAGS)
      .insert({
        name: tag.name,
        color: tag.color,
        user_id: userId,
      })
      .select()
      .single()

    if (error) {
      console.error('Error creating tag:', error)
      throw new Error('Failed to create tag')
    }

    return this.mapTagFromRow(data)
  }

  // Helper methods for prompt-tag relationships
  private async createPromptTags(promptId: string, tags: Tag[]): Promise<void> {
    const promptTags = tags.map(tag => ({
      prompt_id: promptId,
      tag_id: tag.id,
    }))

    const { error } = await supabase
      .from(TABLES.PROMPT_TAGS)
      .insert(promptTags)

    if (error) {
      console.error('Error creating prompt tags:', error)
    }
  }

  private async updatePromptTags(promptId: string, tags: Tag[]): Promise<void> {
    // Delete existing relationships
    await supabase
      .from(TABLES.PROMPT_TAGS)
      .delete()
      .eq('prompt_id', promptId)

    // Create new relationships
    if (tags.length > 0) {
      await this.createPromptTags(promptId, tags)
    }
  }

  // Mapping methods
  private mapPromptFromRow(row: any): Prompt {
    const tags = row.prompt_tags?.map((pt: any) => this.mapTagFromRow(pt.tags)) || []
    const category = row.categories ? this.mapCategoryFromRow(row.categories) : undefined

    // Handle content field - properly split multiple prompts that were joined
    let content: string | string[]

    if (typeof row.content === 'string') {
      // Check if the string contains the separator used when joining multiple prompts
      if (row.content.includes('\n\n')) {
        // Split back into array and filter out empty items
        const splitContent = row.content.split('\n\n')
          .map((item: string) => item.trim())
          .filter((item: string) => item.length > 0)

        // If we have multiple valid items, return as array; otherwise as string
        content = splitContent.length > 1 ? splitContent : row.content
      } else {
        content = row.content
      }
    } else if (Array.isArray(row.content)) {
      content = row.content
    } else {
      content = String(row.content || '')
    }

    return {
      id: row.id,
      title: row.title,
      content,
      description: row.description,
      category,
      tags,
      isFavorite: row.is_favorite,
      usageCount: row.usage_count,
      createdAt: new Date(row.created_at),
      updatedAt: new Date(row.updated_at),
    }
  }

  private mapPromptsFromRows(rows: any[]): Prompt[] {
    return rows.map(row => this.mapPromptFromRow(row))
  }

  private mapCategoryFromRow(row: CategoryRow): Category {
    return {
      id: row.id,
      name: row.name,
      description: row.description,
      color: row.color,
    }
  }

  private mapTagFromRow(row: TagRow): Tag {
    return {
      id: row.id,
      name: row.name,
      color: row.color,
    }
  }
}

export const supabasePromptService = new SupabasePromptService()

import { useEffect, useState } from 'react'
import { useAuth } from '@/hooks/useAuth'
import { supabase } from '@/lib/supabase'
import { useToast } from '@/hooks/use-toast'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { applyTheme, defaultTheme, premadeTheme, type ThemeVariables, parseHslString, hslToHex, hexToHslString } from '@/lib/theme'

export default function Account() {
  const { user } = useAuth()
  const { toast } = useToast()

  const [fullName, setFullName] = useState<string>(user?.user_metadata?.full_name || '')
  const [email, setEmail] = useState<string>(user?.email || '')
  const [password, setPassword] = useState<string>('')
  const [savingProfile, setSavingProfile] = useState(false)
  const [savingSecurity, setSavingSecurity] = useState(false)
  const [themeMode, setThemeMode] = useState<'default' | 'premade' | 'custom'>(() => (user?.user_metadata?.theme_mode as any) || 'default')
  const [themeVars, setThemeVars] = useState<ThemeVariables>({ ...(defaultTheme as ThemeVariables), ...(user?.user_metadata?.theme_vars || {}) })

  useEffect(() => {
    // Apply current theme on mount
    const initial = themeMode === 'premade' ? premadeTheme : themeMode === 'custom' ? themeVars : defaultTheme
    applyTheme(initial)
  }, [])

  if (!user) return null

  const initials = (user.user_metadata?.full_name as string)?.[0]?.toUpperCase() || user.email?.[0]?.toUpperCase() || 'U'

  async function handleSaveProfile(e: React.FormEvent) {
    e.preventDefault()
    setSavingProfile(true)
    const { error } = await supabase.auth.updateUser({
      data: { full_name: fullName },
      // Email change is allowed but will require confirmation; keep it optional here
      ...(email && email !== user.email ? { email } : {}),
    })
    setSavingProfile(false)
    if (error) {
      toast({ title: 'Update failed', description: error.message, variant: 'destructive' })
    } else {
      toast({ title: 'Profile updated', description: 'Your profile has been saved.' })
    }
  }

  async function handleChangePassword(e: React.FormEvent) {
    e.preventDefault()
    if (!password) return
    setSavingSecurity(true)
    const { error } = await supabase.auth.updateUser({ password })
    setSavingSecurity(false)
    if (error) {
      toast({ title: 'Password update failed', description: error.message, variant: 'destructive' })
    } else {
      setPassword('')
      toast({ title: 'Password updated', description: 'Your password has been changed.' })
    }
  }

  function handleThemeModeChange(value: 'default' | 'premade' | 'custom') {
    setThemeMode(value)
    const vars = value === 'premade' ? premadeTheme : value === 'custom' ? themeVars : defaultTheme
    applyTheme(vars)
  }

  function handleThemeVarChange(key: keyof ThemeVariables, value: string) {
    const next = { ...themeVars, [key]: value }
    setThemeVars(next)
    if (themeMode === 'custom') applyTheme(next)
  }

  async function handleSaveTheme(e: React.FormEvent) {
    e.preventDefault()
    const varsToSave = themeMode === 'premade' ? premadeTheme : themeMode === 'custom' ? themeVars : defaultTheme
    const { error } = await supabase.auth.updateUser({
      data: {
        theme_mode: themeMode,
        theme_vars: varsToSave,
      },
    })
    if (error) {
      toast({ title: 'Theme not saved', description: error.message, variant: 'destructive' })
    } else {
      toast({ title: 'Theme saved', description: 'Your theme preferences were saved.' })
    }
  }

  return (
    <div className="min-h-screen w-full p-6">
      <div className="mx-auto max-w-6xl flex flex-col md:flex-row gap-6">
        {/* Left: Profile summary (30%) */}
        <div className="md:basis-[30%] md:max-w-[30%]">
          <Card>
            <CardHeader>
              <CardTitle>Account</CardTitle>
              <CardDescription>Manage your profile and preferences</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4">
                <Avatar className="h-12 w-12">
                  <AvatarFallback>{initials}</AvatarFallback>
                </Avatar>
                <div>
                  <div className="font-medium">{user.user_metadata?.full_name || 'User'}</div>
                  <div className="text-sm text-muted-foreground">{user.email}</div>
                </div>
              </div>
              <Separator className="my-4" />
              <div className="space-y-1 text-sm">
                <div className="text-muted-foreground">User ID</div>
                <div className="truncate">{user.id}</div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right: Tabs (70%) */}
        <div className="md:basis-[70%] md:max-w-[70%]">
          <Tabs defaultValue="profile" className="w-full">
            <TabsList className="w-full justify-start">
              <TabsTrigger value="profile">Profile</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
            </TabsList>

            <TabsContent value="profile" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle>Profile</CardTitle>
                  <CardDescription>Update your name and email</CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSaveProfile} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="full_name">Full name</Label>
                      <Input id="full_name" value={fullName} onChange={(e) => setFullName(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
                    </div>
                    <Button type="submit" disabled={savingProfile}>{savingProfile ? 'Saving…' : 'Save changes'}</Button>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="settings" className="mt-4 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Security</CardTitle>
                  <CardDescription>Manage your password</CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleChangePassword} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="password">New password</Label>
                      <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
                    </div>
                    <Button type="submit" disabled={savingSecurity || !password}>{savingSecurity ? 'Updating…' : 'Update password'}</Button>
                  </form>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Theme</CardTitle>
                  <CardDescription>Pick a premade theme or customize your palette</CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSaveTheme} className="space-y-6">
                    <div className="space-y-2">
                      <Label>Mode</Label>
                      <Select value={themeMode} onValueChange={(v) => handleThemeModeChange(v as any)}>
                        <SelectTrigger className="w-60">
                          <SelectValue placeholder="Select theme" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="default">Default</SelectItem>
                          <SelectItem value="premade">Premade (Cool Blue)</SelectItem>
                          <SelectItem value="custom">Custom</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {themeMode === 'custom' && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {Object.keys(defaultTheme).map((k) => {
                          const hsl = (themeVars as any)[k] as string
                          const { h, s, l } = parseHslString(hsl)
                          const hex = hslToHex(h, s, l)
                          return (
                            <div className="space-y-2" key={k}>
                              <Label htmlFor={k} className="flex items-center justify-between">
                                <span>{k}</span>
                                <span className="text-xs text-muted-foreground">HSL</span>
                              </Label>
                              <div className="flex items-center gap-3">
                                <input
                                  aria-label={`${k} color`}
                                  type="color"
                                  value={hex}
                                  onChange={(e) => handleThemeVarChange(k as keyof ThemeVariables, hexToHslString(e.target.value))}
                                  className="h-9 w-12 rounded-md border border-border bg-transparent"
                                />
                                <Input
                                  id={k}
                                  value={hsl}
                                  onChange={(e) => handleThemeVarChange(k as keyof ThemeVariables, e.target.value)}
                                  placeholder="e.g. 15 12% 11%"
                                />
                              </div>
                            </div>
                          )
                        })}
                      </div>
                    )}

                    <div>
                      <Button type="submit">Save theme</Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}



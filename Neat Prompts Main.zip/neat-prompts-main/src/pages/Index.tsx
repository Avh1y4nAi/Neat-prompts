import { Dashboard } from "@/components/Dashboard";
import { useAuth } from "@/hooks/useAuth";
import { AuthForm } from "@/components/AuthForm";

const Index = () => {
  const { user, isLoading } = useAuth();
  if (isLoading) return null;
  if (!user) return <AuthForm />;
  return <Dashboard />;
};

export default Index;

export interface Prompt {
  id: string;
  title: string;
  content: string | string[];
  description?: string;
  category?: Category;
  tags: Tag[];
  isFavorite: boolean;
  usageCount: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface Category {
  id: string;
  name: string;
  description?: string;
  color?: string;
  count?: number;
}

export interface Tag {
  id: string;
  name: string;
  color?: string;
  count?: number;
}

export interface PromptFormData {
  title: string;
  content: string | string[];
  description?: string;
  category?: string;
  tags: string[];
  isFavorite: boolean;
}

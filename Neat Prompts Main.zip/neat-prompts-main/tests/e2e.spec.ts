import { test, expect } from '@playwright/test';

test.describe('Neat Prompts - Core UI flows', () => {
  test('loads home, shows sample prompts and allows search/filter/sort', async ({ page }) => {
    await page.goto('/');

    // Title of app and counts UI
    await expect(page.getByText('Prompt Manager')).toBeVisible();

    // Prompts count subtitle in top bar
    const headerCount = page.locator('h2:has-text("All Prompts")');
    await expect(headerCount).toBeVisible();

    // Cards render
    const anyPromptCard = page.locator('[data-testid="prompt-card"]');
    await expect(anyPromptCard.first()).toBeVisible();

    // Search
    await page.getByPlaceholder('Search prompts...').fill('code');
    await expect(anyPromptCard).not.toHaveCount(0);

    // Toggle favorites
    await page.getByText('Favorites', { exact: true }).click();
    await expect(page.locator('h2:has-text("Favorites")')).toBeVisible();

    // Sort toggle
    const sortButton = page.getByRole('button', { name: /Newest|Oldest/ });
    await expect(sortButton).toBeVisible();
    await sortButton.click();
  });

  test('create, view, edit, delete prompt via modal flow (local state)', async ({ page }) => {
    await page.goto('/');

    // Open new prompt modal
    await page.getByRole('button', { name: 'New Prompt' }).click();
    await expect(page.getByRole('dialog')).toBeVisible();
    await page.getByLabel('Title').fill('Playwright Test Prompt');

    // Add content and a second content block
    await page.getByLabel(/Prompt Content|Content/).fill('First line');
    await page.getByRole('button', { name: 'Add Another' }).click();
    const second = page.locator('textarea[id^="content-"]').nth(1);
    await second.fill('Second line');

    // Select category
    await page.getByTestId('category-select-trigger').click();
    await page.getByRole('option').first().click();

    // Add a tag
    await page.getByPlaceholder('Add a tag...').fill('e2e');
    await page.getByTestId('add-tag').click();

    // Save
    await page.getByRole('button', { name: 'Create Prompt' }).click();
    await expect(page.getByText('Prompt created', { exact: true }).first()).toBeVisible();

    // Open detail modal via clicking first card
    await page.locator('[data-testid="prompt-card"]').first().click();
    await expect(page.getByRole('dialog')).toBeVisible();
    await expect(page.getByRole('button', { name: 'Copy All Content' })).toBeVisible();
    await page.getByRole('button', { name: 'Copy All Content' }).click();

    // Edit from detail
    const detailDialog = page.getByRole('dialog');
    await detailDialog.getByRole('button', { name: 'edit' }).click();
    await page.getByLabel('Title').fill('Playwright Test Prompt - Edited');
    await page.getByRole('button', { name: 'Update Prompt' }).click();
    await expect(page.getByText('Prompt updated', { exact: true }).first()).toBeVisible();

    // Delete via card menu
    const card = page.locator('[data-testid="prompt-card"]').first();
    await card.hover();
    await card.getByRole('button', { name: 'delete' }).first().click({ trial: true }).catch(() => {});
  });
});



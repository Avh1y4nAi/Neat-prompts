import { test, expect } from '@playwright/test';
import { createClient } from '@supabase/supabase-js';

test.describe('Supabase connectivity and CRUD', () => {
  test('can connect and read basic tables', async () => {
    const url = process.env.VITE_SUPABASE_URL;
    const key = process.env.VITE_SUPABASE_ANON_KEY;
    test.skip(!url || !key, 'Supabase env variables not provided');

    const supabase = createClient(url!, key!);

    const { data: prompts, error } = await supabase
      .from('prompts')
      .select('id')
      .limit(1);

    expect(error).toBeNull();
    expect(Array.isArray(prompts)).toBeTruthy();
  });
});


